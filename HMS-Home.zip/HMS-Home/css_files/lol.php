<?php

session_start();
if (isset($_POST['submit'])) {
	// code...
	$name = $_POST['test'];
	echo $name;
	$_SESSION['user_id'] = $name;
}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>lol</title>
</head>
<body>

	<form method="POST">
		<input type="textbox" name="test">
		<button name="submit">Submit</button>
	</form>

</body>
</html>