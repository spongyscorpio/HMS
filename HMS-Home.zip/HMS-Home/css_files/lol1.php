<?php


echo "Welcome".$_SESSION['user_id'];

?>