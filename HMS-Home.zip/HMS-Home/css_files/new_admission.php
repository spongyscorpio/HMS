<?php 
	
	include('../connection_file/connection.php');

	if (isset($_POST['submit'])) {
		// code...
		$name = $_POST['name'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$mobile_no = $_POST['mobile_no'];
		$pass = $_POST['pass'];
		$college = $_POST['college'];
		$membership =$_POST['membership'];
		$charges = $_POST['charges'];
		$room_no = $_POST['room_no'];

		if (!empty($mobile_no)) {
			// code...
			$query = "INSERT INTO new_std(name, email, address, mobile_no, pass, college, membership, charges, room_no)VALUES('$name', '$email' ,'$address','$mobile_no', '$pass', '$college', '$membership', '$charges', '$room_no')";
			mysqli_query($con, $query);

			
		}
		
	}

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>New Admission | Admin</title>
	<link rel="stylesheet" type="text/css" href="../css_files/new_std_manual.css">
</head>
<body>
	<!-- nav bar -->
	<div class="nav-section">
		<div class="logo">
			<h2>Rajgad Hostel</h2>
		</div>
		<div class="nav-btn-section">
			<li><a class="active" href="ad_home.php">Home</a></li>
            <li><a href="new_std_manual.php">New Admission  </a></li>
            <li><a href="up_std.php">Update Student</a></li>
            <li><a href="fees.php">Fees</a></li>
            <li><a href="living_std.php">Living Student</a></li>
            <li><a href="leaved_std.php">Leaved Student</a></li>
		</div>
	</div>

	<div class="table-section">
		<form method="POST">
			<div class="input-section">
				<input type="text" name="name" placeholder="Enter Full Name : " required>
				<input type="text" name="email" placeholder="Enter Email Address: ">
				<input type="Mobile" name="mobile_no" placeholder="Enter Phone Number : " required="mobile">
				<input type="password" name="pass" placeholder="Create Password : ">
				<input type="text" name="address" placeholder="Enter Address : ">
				<input type="text" name="">
				
				<select name="college">
					<option>
						Select College : 
					</option>
					<option>SIMCA</option>
					<option>SITS</option>
					<option>SIOP</option>
					
				</select>
				
				<select name="membership">
					<option>
						Select Membership : 
					</option>
					<option>Quarterly</option>
					<option>Yearly</option>
				</select>

				<select name="charges">
					<option>
						charges : 
					</option>
					<option>41000</option>
					<option>72000</option>
				</select>

				<select name="room_no">
					<option>
						Select the room number :
					</option>

					<?php

						include('../connection_file/connection.php');
						$query = "SELECT * FROM rooms WHERE roomStatus = 'Not booked'";
						$data = mysqli_query($con, $query);
						$total = mysqli_num_rows($data);

						if($total != 0){

							while($result = mysqli_fetch_assoc($data)){
								echo "<option>".$result['room_no']."</option>";
								
							}
							$query1 = "update rooms set roomStatus = 'Booked' where room_no = '$room_no'";
							mysqli_query($con, $query1);				
							header("Location: new_std_manual.php");
						}

					?>
					
				</select>



			</div>
			<center><button name="submit">Submit</button></center>
		</form>
		
	</div>


	

</body>
</html>