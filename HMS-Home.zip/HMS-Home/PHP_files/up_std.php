<?php 
                     

   include("../connection_file/connection.php");

      if(isset($_POST['remove']))
         {
                           //something was posted
                           
            $mobile_no = $_POST['mobile_no'];
            $room_no = $_POST['room_no'];

            if(!empty($mobile_no))
               {

                              //save to database
                              
                  $query = "delete from new_std where mobile_no = $mobile_no";

                  mysqli_query($con, $query);

                  $update_query1 = "UPDATE rooms SET roomStatus = 'Not booked' WHERE room_no = $room_no";
                   mysqli_query($con, $update_query1);

                  header("Location: up_std.php");

                  die;
                  }else
                  {
                      echo "Data is not pushed";
                   }
               }
                        
?>
<?php 
                     

   include("../connection_file/connection.php");

                        


   if(isset($_POST['update']))
                        {
                           //something was posted
                           $mobile_no = $_POST['mobile_no'];
                           $name = $_POST['name'];
                           $email = $_POST['email'];
                           $address = $_POST['address'];
                           $college = $_POST['college'];
                           $room_no = $_POST['room_no'];
                           $membership = $_POST['membership'];
                           $status = $_POST['status'];

                           if(!empty($room_no))
                           {

                              //save to database
                              
                              $query = "update new_std set name = '$name', email = '$email', address = '$address', college = '$college', room_no = '$room_no', status = '$status' where mobile_no = $mobile_no";

                              mysqli_query($con, $query);
                              header("Location: up_std.php");

                              die;
                           }else
                           {
                              echo "Data is not pushed";
                           }
                        }
                       
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Update Student | Admin</title>
      <link rel="stylesheet" href="../css_files/up_std.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
      <nav>
         <div class="logo">
            Rajgad Hostel
         </div>
         <input type="checkbox" id="click">
         <label for="click" class="menu-btn">
         <i class="fas fa-bars">X</i>
         </label>
         <ul>
            <li><a class="active" href="ad_home.php">Home</a></li>
            <li><a href="new_admission.php">New Admission  </a></li>
            <li><a href="up_std.php">Update Student</a></li>
            <li><a href="fees.php">Fees</a></li>
            <li><a href="living_std.php">Living Student</a></li>
            <li><a href="leaved_std.php">Leaved Student</a></li>
         </ul>
      </nav>
      <div class="search-section">

         <div class="section">

            <form method="POST">
               <center><input type="mobile" name="mobile_no" class="center" placeholder="Enter Mobile No :" maxlength = "10" required>
               <button name="search">Search</button></center>
            

            <?php
               include('../connection_file/connection.php');

               if (isset($_POST['search'])) {

                  $mobile_no = $_POST['mobile_no'];
                  // code...

                  if (!empty($mobile_no)) {
                     // code...
                     $query = "SELECT * FROM new_std WHERE mobile_no = $mobile_no";
                     $query_run = mysqli_query($con, $query);

                     if (mysqli_num_rows($query_run) > 0) {
                              # code...
                              while ($row = mysqli_fetch_array($query_run)) {
                                 # code

                                 ?>
                           <input type="mobile" name="name" class="center" placeholder="Enter Mobile No :" value="<?php echo $row['name'] ?>" required>
                           <input type="mobile" name="email" class="center" placeholder="Enter Mobile No :" value="<?php echo $row['email'] ?>" required>
                           <input type="mobile" name="address" class="center" placeholder="Enter Mobile No :" value="<?php echo $row['address'] ?>" required>
                           <input type="mobile" name="college" class="center" placeholder="Enter Mobile No :" value="<?php echo $row['college'] ?>" required>
                           <input type="mobile" name="room_no" class="center" placeholder="Enter Mobile No :" value="<?php echo $row['room_no'] ?>" required>
                           <input type="mobile" name="membership" class="center" placeholder="Enter Mobile No :" value="<?php echo $row['membership'] ?>" required>
                           <input type="mobile" name="charges" class="center" placeholder="Enter Mobile No :" value="<?php echo $row['charges'] ?>" required>
                           <input type="mobile" name="status" class="center" placeholder="Status" value="<?php echo $row['status'] ?>" required>

                           <center>
                              <button name="update" class="btn">Update</button>
                              <button name="remove">delete</button>

                           </center>
                           <?php
                        }
                     }

                  }

               }
            ?>
            </form>
            
         </div>

      </div>

      <div class="table">

         <div class="table-section">
            
            <form>
               <div class="table-size" style="overflow-x:auto; overflow-y:auto;">
               <table>
                  <tr>
                     <th>Name</th>
                     <th>Email</th>
                     <th>Address</th>
                     <th>Room No</th>
                     <th>Mobile No</th>
                     <th>Membership</th>
                     <th>College</th>
                     <th>Status</th>
                  </tr>

                  <?php 
                     include('../connection_file/connection.php');
                     $query = "SELECT * FROM new_std";
                     $query_run = mysqli_query($con, $query);

                     if (mysqli_num_rows($query_run)) {

                        // code...
                        while($result = mysqli_fetch_array($query_run)){
                           echo "
                           <tr>
                              <td>".$result['name']."</td>
                              <td>".$result['email']."</td>
                              <td>".$result['address']."</td>
                              <td>".$result['room_no']."</td>
                              <td>".$result['mobile_no']."</td>
                              <td>".$result['membership']."</td>
                              <td>".$result['college']."</td>
                              <td>".$result['status']."</td>
                           </tr>

                           ";
                        }
                     }

                  ?>

               </table>
            </div>
            </form>


         </div>
            
      </div>

      <footer class="footer">
            <center>@all rights reserved by Nilesh Oulkar</center>
      </footer>



   </body>


</html>