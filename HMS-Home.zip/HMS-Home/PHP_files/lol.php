    <?php
        $db = mysqli_connect("localhost", "root", "", "hostel");
        $query = "SELECT * FROM image where mobile_no= 0";
        $result = mysqli_query($db, $query);
 
        while ($data = mysqli_fetch_assoc($result)) {
    ?>
        <img src="../image/<?php echo $data['filename']; ?>">
 
    <?php
        }
    ?>     