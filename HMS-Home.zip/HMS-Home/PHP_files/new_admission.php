
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Update Student | Admin</title>
      <link rel="stylesheet" href="../css_files/new_admission.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
      <nav>
         <div class="logo">
            Rajgad Hostel
         </div>
         <input type="checkbox" id="click">
         <label for="click" class="menu-btn">
         <i class="fas fa-bars"></i>
         </label>
         <ul>
            <li><a class="active" href="ad_home.php">Home</a></li>
            <li><a href="new_admission.php">New Admission  </a></li>
            <li><a href="up_std.php">Update Student</a></li>
            <li><a href="fees.php">Fees</a></li>
            <li><a href="living_std.php">Living Student</a></li>
            <li><a href="leaved_std.php">Leaved Student</a></li>
         </ul>
      </nav>

      <div class="input-section">
         <center>
            <div class="input">
               <form method="POST" enctype="multipart/form-data">
                  <input type="text" name="mobile_no" placeholder="Enter Mobile Number.." maxlength="10" required>
                  <input type="text" name="name" placeholder="Enter Name.." required>
                  <input class="form-control" type="file" name="uploadfile" value="" />
                  <input type="Email" name="email" placeholder="Enter Email.." required>
                  <input type="Address" name="address" placeholder="Enter Address.."  required="">
                  <input type="password" name="pass" placeholder="Create Password.." maxlength="10" required="">
                  <select class="select" name="college">
                     <option>--Select College--</option>
                     <option>SIMCA</option>
                     <option>SIOP</option>
                     <option>SITS</option>
                  </select>

                  <select class="select" name="membership">
                     <option>--Membership--</option>
                     <option>--Yearly--</option>
                     <option>--Quarterly--</option>
                  </select>

                  <select name="room_no" class="select" >

                              <option>Select Room</option>

                            
                                <?php

                                 include('../connection_file/connection.php');
                                 $query = "select * from rooms where roomStatus = 'Not booked'";
                                 $data = mysqli_query($con, $query);
                                 $total = mysqli_num_rows($data);

                                 if($total != 0) {
                                    
                                    while($result = mysqli_fetch_assoc($data))
                                    {
                                       echo "<option>".$result['room_no']."</option>";
                  
                                    }
                                 }
                                 else
                                 {
                                    echo "Data Not Found";
                                 }
                              ?>
                  </select>

                  <button name="submit">Submit</button>
                  <?php
                  session_start();
                        include('../connection_file/connection.php');
                        if(isset($_POST['submit'])){
                           # code...
                           $name = $_POST['name'];
                           $email = $_POST['email'];
                           $address = $_POST['address'];
                           $pass = $_POST['pass'];
                           $room_no = $_POST['room_no'];
                           $mobile_no = $_POST['mobile_no'];
                           $membership = $_POST['membership'];
                           $college = $_POST['college'];
                           
                           

                           if (!empty($name)) {
                              # code...
                              $query = "INSERT INTO new_std(name, email, address, pass, room_no,mobile_no, membership, college) VALUES('$name' ,'$email', '$address', '$pass', '$room_no', '$mobile_no','$membership','$college')";
                              mysqli_query($con, $query);

                              $filename = $_FILES["uploadfile"]["name"];
                              $tempname = $_FILES["uploadfile"]["tmp_name"];
                              $folder = "../image/" . $filename;
 
                              $db = mysqli_connect("localhost", "root", "", "hostel");
 
                              // Get all the submitted data from the form
   
                              $sql = "UPDATE new_std set image = '$filename' where mobile_no = $mobile_no";
                              mysqli_query($db, $sql);

                              if (move_uploaded_file($tempname, $folder)) {
                                 echo "<h3>  Successfullly Inserted!</h3>";
                              } else {
                                 echo "<h3>  Failed to upload image!</h3>";
                              }


                              if ($membership == '--Yearly--') {
                                 // code...
                                 $query1 = "UPDATE new_std SET charges = '72000' WHERE mobile_no = $mobile_no";
                                 mysqli_query($con, $query1);

                                 $fees_query = "UPDATE new_std SET pending_fees = '72000' WHERE mobile_no = $mobile_no";
                                 mysqli_query($con, $fees_query);


                              }
                              elseif ($membership  == '--Quarterly--') {

                                 $query1 = "UPDATE new_std SET charges = '42000' WHERE mobile_no = '$mobile_no'";
                                 mysqli_query($con, $query1);

                                 $fees_query1 = "UPDATE new_std SET pending_fees = '42000' WHERE mobile_no = '$mobile_no'";
                                 mysqli_query($con, $fees_query1);
                                 
                              }

                              $query2 = "UPDATE rooms SET roomStatus = 'Booked' WHERE room_no = $room_no";
                              mysqli_query($con, $query2);

                              header('Location: new_admission.php');

                              
  
                                           
                           }
                           else{
                              echo "Please fill all information";
                           }
                        }
                        
                  ?>
               </form>
               
            </div>
         </center>
      </div>
      <div class="table">

         <div class="table-section">
            
            <form>
               <div class="table-size" style="overflow-x:auto; overflow-y:auto;">
               <table>
                  <tr>
                     <th>Name</th>
                     <th>Email</th>
                     <th>Address</th>
                     <th>Room No</th>
                     <th>Mobile No</th>
                     <th>Membership</th>
                     <th>College</th>
                     <th>Status</th>
                  </tr>

                  <?php 
                     include('../connection_file/connection.php');
                     $query = "SELECT * FROM new_std";
                     $query_run = mysqli_query($con, $query);

                     if (mysqli_num_rows($query_run)) {

                        // code...
                        while($result = mysqli_fetch_array($query_run)){
                           echo "
                           <tr>
                              <td>".$result['name']."</td>
                              <td>".$result['email']."</td>
                              <td>".$result['address']."</td>
                              <td>".$result['room_no']."</td>
                              <td>".$result['mobile_no']."</td>
                              <td>".$result['membership']."</td>
                              <td>".$result['college']."</td>
                              <td>".$result['status']."</td>
                           </tr>

                           ";
                        }
                     }

                  ?>

               </table>
            </div>
            </form>


         </div>
            
      </div>
      

      <footer class="footer">
            <center>@all rights reserved by Nilesh Oulkar</center>
      </footer>



   </body>
   


</html>