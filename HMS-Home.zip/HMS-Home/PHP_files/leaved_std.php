
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Update Student | Admin</title>
      <link rel="stylesheet" href="../css_files/leaved_std.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <style type="text/css">
      button{
  padding: 8px 40px;
  cursor: pointer;
}
   </style>
   <body>
      <nav>
         <div class="logo">
            Rajgad Hostel
         </div>
         <input type="checkbox" id="click">
         <label for="click" class="menu-btn">
         <i class="fas fa-bars"></i>
         </label>
         <ul>
            <li><a class="active" href="ad_home.php">Home</a></li>
            <li><a href="new_admission.php">New Admission  </a></li>
            <li><a href="up_std.php">Update Student</a></li>
            <li><a href="fees.php">Fees</a></li>
            <li><a href="living_std.php">Living Student</a></li>
            <li><a href="leaved.php">Leaved Student</a></li>
         </ul>
      </nav>


   <center>
      <div class="table">

         <div class="table-section">
            
            <form>
               <div class="table-size" style="overflow-x:auto; overflow-y:auto;">
                  <center><h2>Student Data:</h2></center>
               <table>
                  <tr>
                     <th>Name</th>
                     <th>Email</th>
                     <th>Address</th>
                     <th>Room No</th>
                     <th>Mobile No</th>
                     <th>Membership</th>
                     <th>College</th>
                     <th>Status</th>
                  </tr>

                  <?php 
                     include('../connection_file/connection.php');
                     $query = "SELECT * FROM new_std WHERE status = 'leaved'";
                     $query_run = mysqli_query($con, $query);

                     if (mysqli_num_rows($query_run)) {

                        // code...
                        while($result = mysqli_fetch_array($query_run)){
                           echo "
                           <tr>
                              <td>".$result['name']."</td>
                              <td>".$result['email']."</td>
                              <td>".$result['address']."</td>
                              <td>".$result['room_no']."</td>
                              <td>".$result['mobile_no']."</td>
                              <td>".$result['membership']."</td>
                              <td>".$result['college']."</td>
                              <td>".$result['status']."</td>
                           </tr>

                           ";
                        }
                     }

                  ?>

               </table>
            </div>
            <center><button onclick="window.print();" class="btn btn-primary" id="print-btn">Print</button></center>
            </form>


         </div>
            
      </div>
   </center>

      <footer class="footer">
            <center>@all rights reserved by Nilesh Oulkar</center>
      </footer>



   </body>


</html>