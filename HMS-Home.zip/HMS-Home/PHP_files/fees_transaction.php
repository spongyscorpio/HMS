<?php 
   
      error_reporting(0);
      include('../connection_file/connection.php');
            
                     if(isset($_POST['submit'])) 
                     {
                        if (isset($_POST['submit'])){
                           // code...
                           $name = $_POST['name'];
                           $room_no = $_POST['room_no'];
                           $mobile_no = $_POST['mobile_no'];
                           $amount_paying = $_POST['amount'];
                           $date = $_POST['date'];


                           $query = "SELECT * FROM new_std WHERE room_no = '$room_no'";
                           $query_run = mysqli_query($con, $query);

                           $row = mysqli_fetch_array($query_run);
                           $pending_fees = $row[10];

                           if ($pending_fees > 0) {
                        
                              $result =  $row[10] - $_POST['amount'];

                              $query1 = "UPDATE new_std SET pending_fees = $result where room_no = '$room_no'";
                              mysqli_query($con, $query1);

                              $insert_query = "INSERT INTO fees(name, room_no, amount_paid, DT, mobile_no) VALUES('$name', '$room_no', '$amount_paying', '$date', '$mobile_no')";
                              mysqli_query($con, $insert_query);

                              echo "Data Inserted";
                           }

                           else{
                           echo "Fees already paid by $mobile_no";
                           }


                        }
                        else
                           echo "middle";
                     }
           
   ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Fees Transaction | Admin</title>
      <link rel="stylesheet" href="../css_files/fees.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
      <nav>
         <div class="logo">
            Rajgad Hostel
         </div>
         <input type="checkbox" id="click">
         <label for="click" class="menu-btn">
         <i class="fas fa-bars"></i>
         </label>
         <ul>
            <li><a class="active" href="ad_home.php">Home</a></li>
            <li><a href="new_admission.php">New Admission  </a></li>
            <li><a href="up_std.php">Update Student</a></li>
            <li><a href="fees.php">Fees</a></li>
            <li><a href="living_std.php">Living Student</a></li>
            <li><a href="leaved_std.php">Leaved Student</a></li>
         </ul>
      </nav>

      <div class="input-section">
         <center><h1>Transaction Section</h1></center>
         <center>
            <div class="input">
               <form method="POST">
                  <input type="text" placeholder ="Enter your mobile number.." name="mobile_no" maxlength="10">
                  <center><button name="search" class="btn">Search</button></center>
                     <?php
               include('../connection_file/connection.php');

               if (isset($_POST['search'])) {

                  $mobile_no = $_POST['mobile_no'];
                  // code...

                  if (!empty($mobile_no)) {
                     // code...
                     $query = "SELECT * FROM new_std WHERE mobile_no = $mobile_no";
                     $query_run = mysqli_query($con, $query);

                     if (mysqli_num_rows($query_run) > 0) {
                              # code...
                              while ($row = mysqli_fetch_array($query_run)) {
                                 # code

                                 ?>

                           

                           
                           <?php
                        }
                     }

                  }

               }
            ?>
                  

               </form>
               
            </div>
         </center>
      </div>
      <div class="table">

         <div class="table-section">
            
            <form>
               <div class="table-size" style="overflow-x:auto; overflow-y:auto;">
               <table>
                  <tr>
                     <th>Name</th>
                     <th>Room No</th>
                     <th>Date</th>
                     <th>Amount Paying</th>
                     <th>Mobile No</th>

                  </tr>

                  <?php 
                     include('../connection_file/connection.php');
                     $query = "SELECT * FROM fees where mobile_no = $mobile_no";
                     $query_run = mysqli_query($con, $query);

                     if (mysqli_num_rows($query_run)) {

                        // code...
                        while($result = mysqli_fetch_array($query_run)){
                           echo "
                           <tr>
                              <td>".$result['name']."</td>
                              <td>".$result['room_no']."</td>
                              <td>".$result['DT']."</td>
                              <td>".$result['amount_paid']."</td>
                              <td>".$result['mobile_no']."</td>
                        
                           </tr>

                           ";
                        }
                     }

                  ?>

               </table>

            </div>
            </form>



         </div>
            
      </div>
      

      <footer class="footer">
            <center>@all rights reserved by Nilesh Oulkar</center>
      </footer>



   </body>
   


</html>