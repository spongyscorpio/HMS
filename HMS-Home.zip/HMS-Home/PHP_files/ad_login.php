


<!DOCTYPE html>
<html>
<head>
	<title>Admin Login | Rajgad Hostel</title>
	<link rel="stylesheet" type="text/css" href="../css_files/ad_login.css">
</head>
<body>
	<div class="container">
		<div class="form-login">
			<h1>Admin Login</h1>
			<form method="POST">

				<div class="form-input">
					<input type="textbox" placeholder = "Username" name="user_name" required>
				</div>

				<div class="form-input1">
					<input type="password" placeholder = "Password" name="password" required>
				</div>
				<div class="btn1">
					
					<button class="btn">Login</button>
					
				</div>
				<?php 

session_start();

	include('../connection_file/connection.php');
	


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if(!empty($user_name) && !empty($password))
		{

			//read from database
			$query = "select * from ad_users where user_name = '$user_name' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: ad_home.php");
						die;
					}
				}
			}
			
			echo "wrong username or password!";
		}else
		{
			echo "wrong username or password!";
		}
	}

?>			
			</form>
		</div>
	</div>


</body>
</html>