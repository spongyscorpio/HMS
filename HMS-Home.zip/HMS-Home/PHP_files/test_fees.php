<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>


	<?php 

		
		include('../connection_file/connection.php');
             
                        if($_SERVER['REQUEST_METHOD'] == "POST") {

                        	$mobile_no = $_POST['mobile_no'];

                        	$query = "SELECT * FROM new_std WHERE mobile_no = '$mobile_no'";
           				    $query_run = mysqli_query($con, $query);

            				$row = mysqli_fetch_array($query_run);
            				$pending_fees = $row[8];

            				if ($pending_fees != 0) {
            				
            				$result =  $row[8] + $_POST['amount'];
            				echo $row[8];
            				echo $_POST['amount'];
            				echo $result;

            				$query1 = "UPDATE new_std SET pending_fees = $result where mobile_no = $mobile_no";
            				mysqli_query($con, $query1);
            				}
            				else{
            				echo "Fees already paid by $mobile_no";
            				}

                        }

           
	?>

	<form method="POST">
		<input type="text" maxlength="10" name="mobile_no" placeholder="mobile">
		<input type="tetx" name="amount">
		<button>Submit</button>
		
	</form>

</body>
</html>