<!DOCTYPE html>
<html>
<head>
	<title>Student Login | Rajgad Hostel</title>
	<link rel="stylesheet" type="text/css" href="../../css_files/ad_login.css">
	<style type="text/css">
		

*{
	padding: 0px;
	margin: 0px;

}
body{

	height: 100vh;
	display: flex;
	align-items: center;
	justify-content: center;
	background-color: grey;


}
.container{
	width: 400px;
	height: 280px;
	background-color: white;
	display: flex;
	align-items: center;
	justify-content: center;
	border-radius: 10px;
}
.form-login{

	margin-top: 50px;
}


.form-login h1{
	font-size: 30px;
	margin-top: -50px;
	position: absolute;
}


.form-input{
	
	width: 80%;

}

.form-input input{
	
	width: 300px;
	border: none;
	outline: none;
	background: none;
	border-bottom: 1px solid black;
	font-size: 15px;
	padding: 8px 8px;


}

.form-input1 input{
	width: 300px;
	margin-top: 20px;
	border: none;
	outline: none;
	background: none;
	border-bottom: 1px solid black;
	font-size: 15px;
	padding: 8px 8px;
	position: absolute;

}

.btn{
	margin-top: 80px;
	max-width: 330px;
	width: 100%;
	border-radius: 10px;
	height: 40px;
	font-size: 18px;
	cursor: pointer;
	transition: 0.4s;
	
}

.btn:hover{
	font-size: 22px;
	transition: 0.3s;
	font-family: sans-serif;
}

form h4{
	margin-top: 25px;
	text-align: center;
}

.sign-up{

	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: 80px;
	background-color: transparent;
}

.sign-up a{
	margin-left: 5px;
	text-decoration: none;
	color: blue;
	transition: 0.1s;
	border-bottom: 1px solid blue;
	font-family: sans-serif;

}

.sign-up a:hover{
	font-size: 18px;
	transition: 0.1s;
}

@media screen and (max-width: 768px){
	body{
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.container{
		width: 80%;
	}

	.form-login{
		width: 80%;
		
		
	}

	
	form{
		width: 90%;
		
	}

	.form-input{
		width: 100%;
		

	}

	.form-input input{
		width: 100%;
		
	}

	.form-input1{
		width: 100%;
		

	}

	.form-input1 input{
		width: 58%;
		
	}

	.btn1{
		display: flex;
		align-items: center;
		justify-content: center;
		margin-left: 18px;
	}

	.btn1 .btn{
		max-width: 350px;
		width: 100%;
	}

}
	</style>
</head>
<body>
	<div class="container">
		<div class="form-login">
			<h1>Student Login</h1>
			<form method="POST">	<!-- lol-->

				<div class="form-input">
					<input type="textbox" placeholder = "Username" name="user_name" required>
				</div>

				<div class="form-input1">
					<input type="password" placeholder = "Password" name="password" required>
				</div>
				<div class="btn1">
					
					<button name="submit" class="btn">Login</button>
					
				</div>

<?php 

	

	include('../connection_file/connection.php');
	
	session_start();


	if(isset($_POST['submit']))
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];
		


		if(!empty($user_name) && !empty($password))
		{

			//read from database
			$query = "select * from new_std where name = '$user_name' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['pass'] === $password)
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						$_SESSION['user_name'] = $user_name;
						$_SESSION['password'] = $password;
						header("Location: std_home.php");
						die;
					}
				}
			}
			
			echo "wrong username or password!";
		}else
		{
			echo "wrong username or password!";
		}
	}
?>
				
		</form>
		
		</div>
	</div>




</body>
</html>