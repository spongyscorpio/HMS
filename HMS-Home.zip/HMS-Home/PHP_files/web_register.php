
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Update Student | Admin</title>
      <link rel="stylesheet" href="../css_files/leaved_std.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
      <nav>
         <div class="logo">
            Rajgad Hostel
         </div>
         <input type="checkbox" id="click">
         <label for="click" class="menu-btn">
         <i class="fas fa-bars"></i>
         </label>
         <ul>
            <li><a class="active" href="ad_home.php">Home</a></li>
            <li><a href="new_std_manual.php">New Admission  </a></li>
            <li><a href="up_std.php">Update Student</a></li>
            <li><a href="fees.php">Fees</a></li>
            <li><a href="living_std.php">Living Student</a></li>
            <li><a href="leaved.php">Leaved Student</a></li>
         </ul>
      </nav>


   <center>
      <div class="table">

         <div class="table-section">
            
               <input type="mobile" name="mobile_no" class="center" placeholder="Enter Mobile No :" maxlength = "10" required>
               <input type="mobile" name="name" class="center" placeholder="Enter Mobile No :" required>
               <input type="mobile" name="email" class="center" placeholder="Enter Mobile No :" required>
               <input type="mobile" name="address" class="center" placeholder="Enter Mobile No :" required>
               <input type="mobile" name="college" class="center" placeholder="Enter Mobile No :" required>
               <input type="mobile" name="room_no" class="center" placeholder="Enter Mobile No :" required>
               <input type="mobile" name="membership" class="center" placeholder="Enter Mobile No : required>
               <input type="mobile" name="charges" class="center" placeholder="Enter Mobile No :" required>
               <input type="mobile" name="status" class="center" placeholder="Status" required>


         </div>
            
      </div>
   </center>

      <footer class="footer">
            <center>@all rights reserved by Nilesh Oulkar</center>
      </footer>



   </body>


</html>