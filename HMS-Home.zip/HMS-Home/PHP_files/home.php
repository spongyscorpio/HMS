<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css_files/home.css">
	<title>Home | Rajgad Hostel</title>
</head>
<body>
	<nav>
		<a href="ad_login.php">Admin Login</a>
		<a href="testad_login.php">Student Login</a>
		
		
	</nav>

	<div class="container">
		<div class="left-section">
			<div class="img">
				<center><img src="new_std.png"></center>
			</div>
		</div>

		<div class="right-section">
			<div class="section">
				<h1>|Rajgad Hostel</h1>
				<article>I’ve called out Dropbox before as an excellent example of good marketing all around. The company’s homepage is no different. You have a slightly askew hero image that draws the eye and two CTAs — one of which uses a dark background to draw more attention since it’s for the paid version of the tool.

				The marketing copy is very simple here. Dropbox knows its target audience and drills down on pain points that affect them, including efficiency and security. Plus, the navigation is pretty stripped down, with an option to “Compare plans.”</article>
				<p>“IN HOSTEL LIFE NIGHTS TURNED INTO

				MORNING, WITH THE FRIENDS

				THAT’S TURN INTO FAMILY.”</p>
				<a href="web_charges.php">Learn More??</a>
			</div>
		</div>
	</div>

</body>
</html>