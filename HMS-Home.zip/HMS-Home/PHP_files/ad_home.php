
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Update Student | Admin</title>
      <link rel="stylesheet" href="../css_files/ad_home.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
      <nav>
         <div class="logo">
            Rajgad Hostel
         </div>
         <input type="checkbox" id="click">
         <label for="click" class="menu-btn">
         <i class="fas fa-bars"></i>
         </label>
         <ul>
            <li><a class="active" href="ad_home.php">Home</a></li>
            <li><a href="new_admission.php">New Admission  </a></li>
            <li><a href="up_std.php">Update Student</a></li>
            <li><a href="fees.php">Fees</a></li>
            <li><a href="living_std.php">Living Student</a></li>
            <li><a href="leaved_std.php">Leaved Student</a></li>
         </ul>
      </nav>
      <a href="registerAdmin.php">
         <button class="btn">Register Admin</button>
      </a>
      <div class="room-section">

         <center>
            <div class="display-section">

               <form method="GET">
                  <div class="table-size" style="overflow-x:auto; overflow-y:auto;">
               <table>
                  <center><h3>Rooms section</h3></center>
                  <tr>
                     <th>Room No</th>
                     <th>Room Status</th>
                     <th>Status</th>
                     <th>Edit</th>
                     

                  </tr>

                  <?php 
                     include('../connection_file/connection.php');
                     $query = "SELECT * FROM rooms";
                     $query_run = mysqli_query($con, $query);

                     if (mysqli_num_rows($query_run)) {

                        // code...
                        while($result = mysqli_fetch_array($query_run)){
                           echo "
                           <tr>
                              <td>".$result['room_no']."</td>
                              <td>".$result['roomStatus']."</td>
                              <td>".$result['status']."</td>

                              <td><a href='edit_room.php?rn=$result[room_no]&rS=$result[roomStatus]&status=$result[status]'>
                                 Edit
                              </a></td>
                              


                           </tr>

                           ";
                        }
                     }

                  ?>

               </table>

               </form>
               
            </div>
         </center>
      </div>

      <div class="heading">
            <div class="heading-content">
               <div class="content">
                  <h1>Rajgad Hostel</h1>
                  <h3>Sinhgad Collge, Narhe</h3>
               </div>
            </div>
         
      </div>

      <footer class="footer">
            <h3>@all rights reserved by Nilesh Oulkar</h3>
      </footer>



   </body>


</html>