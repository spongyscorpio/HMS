
<!DOCTYPE html>
<html>
<head>
	<title>Register Page | Rajgad Hostel</title>
</head>

<style type="text/css">
	*{
		padding: 0;
		margin: 0;

	}

	.container{
		width: 100%;
		height: 100vh;
		background-color: rgb(0,0,0,0.8);
		display: flex;
		justify-content: center;
		align-items: center;

	}

	.section{
		width: 42%;
		height: 65vh;
		background-color: white;
		border-radius: 30px;
		padding-right: 20px;
	}

	.first-section{
		width: 100%;
		height: 30px;
		
	}

	.section h2{
		margin-top: 20px;
		margin-left: 30px;
		font-size: 30px;
	}
	.input-section{
		width: 100%;
		height: 50vh;
		margin-top: 20px;
		
	}

	.input-section input{
		padding: 10px 10px;
		width: 40%;
		margin-top: 40px;
		margin-left: 30px;
		outline: none;
		background: none;
		border-left: none;
		border-right: none;
		border-top: none;

	}
	.input-section select{
		padding: 10px 10px;
		width: 44%;
		margin-top: 40px;
		margin-left: 30px;
		outline: none;
		background: none;
		border-left: none;
		border-right: none;
		border-top: none;
	}

	.input-section button{
		padding: 8px 30px;
		margin-top: 30px;
		cursor: pointer;

	}
	.input-section .membership{
		padding: 10px 10px;
		width: 44%;
		margin-top: 40px;
		margin-left: 25%;
		outline: none;
		background: none;
		border-left: none;
		border-right: none;
		border-top: none;

	}


</style>

<body>
<div class="container">
	<div class="section">
		<div class="first-section">
			<h2>Register</h2>
		</div>
		<form method="POST">			
			<div class="input-section">
				  <input type="text" name="mobile_no" placeholder="Enter Mobile Number.." maxlength="10" required>
                  <input type="text" name="name" placeholder="Enter Name.." required>
                  <input type="Email" name="email" placeholder="Enter Email.." required>
                  <input type="Address" name="address" placeholder="Enter Address.."  required>
                  <input type="password" name="pass" placeholder="Create Password.." maxlength="10" required="">
                  <select class="select" name="college">
                     <option>--Select College--</option>
                     <option>SIMCA</option>
                     <option>SIOP</option>
                     <option>SITS</option>
                  </select>

                  <select class="membership" name="membership">
                     <option>--Membership--</option>
                     <option>--Yearly--</option>
                     <option>--Quarterly--</option>
                  </select>

                  <center><button name="submit">Submit</button>	</center>
           
			</div>
		</form>
		<?php
                  session_start();
                        include('../connection_file/connection.php');
                        if(isset($_POST['submit'])){
                           # code...
                           $name = $_POST['name'];
                           $email = $_POST['email'];
                           $address = $_POST['address'];
                           $pass = $_POST['pass'];
                           $mobile_no = $_POST['mobile_no'];
                           $membership = $_POST['membership'];
                           $college = $_POST['college'];
                           

                           
                           

                           if (!empty($name)) {
                              # code...
                              $query = "INSERT INTO web_register(name, email, address, password,mobile_no, membership, college) VALUES('$name' ,'$email', '$address', '$pass', '$mobile_no','$membership','$college')";
                              mysqli_query($con, $query);

                              if ($membership == '--Yearly--') {
                                 // code...
                                 $query1 = "UPDATE web_register SET charges = '72000' WHERE mobile_no = $mobile_no";
                                 mysqli_query($con, $query1);


                              }
                              elseif ($membership  == '--Quarterly--') {

                                 $query1 = "UPDATE web_register SET charges = '42000' WHERE mobile_no = '$mobile_no'";
                                 mysqli_query($con, $query1);

                                 
                                 
                              }

                              

                              
  
                                           
                           }
                           else{
                              echo "Please fill all information";
                           }
                        }
                        
                  ?>
	</div>

</div>
</body>
</html>

 