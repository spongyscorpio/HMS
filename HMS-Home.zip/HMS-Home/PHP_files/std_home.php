<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
    <style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
} 
nav{
  display: flex;
  height: 12vh;
  width: 100%;
  background-color: rgb(0, 0, 0, 0.4);
  align-items: center;
  justify-content: space-between;
  padding: 0 50px 0 100px;
  flex-wrap: wrap;
}
nav .logo{
  color: #fff;
  font-size: 35px;
  font-weight: 600;
}
nav ul{
  display: flex;
  flex-wrap: wrap;
  list-style: none;
}
nav ul li{
  margin: 0 5px;
}
nav ul li a{
  color: #f2f2f2;
  text-decoration: none;
  font-size: 18px;
  font-weight: 500;
  padding: 8px 15px;
  border-radius: 5px;
  letter-spacing: 1px;
  transition: all 0.3s ease;
}
nav ul li a.active,
nav ul li a:hover{
  color: #111;
  background: #fff;
}
nav .menu-btn i{
  color: #fff;
  font-size: 22px;
  cursor: pointer;
  display: none;
}
input[type="checkbox"]{
  display: none;
}




body{
  background-image: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.3)), url('../img/bg_gr.jpg');
  background-size: cover;
  background-repeat: no-repeat;
  height: 100vh;
  width: 100%;

}


.container{
  margin-top: 8%;
  height: 60vh;
  width: 50%;
  background-color: whitesmoke;
  border-top-left-radius: 200px;
  border-bottom-left-radius: 200px;

}

.container .left-section{
  float: left;
  width: 40%;
  height: 100%;
  background-color: antiquewhite;
  border-top-left-radius: 200px;
  border-bottom-left-radius: 200px;
}

.container .left-section img{
  margin-top: 35%;
  width: 250px;
  height: 250px;
  border-radius: 100px;
}

.container .right-section{
  width: 60%;
  height: 100%;
  float: right;
}

.container .right-section input{
    
    
    outline: none;
    border-bottom: 2px solid black;
    padding: 10px 20px;
    width: 40%;
    margin-top: 60px;

}

.container .right-section button{
  padding: 10px 30px;
  cursor: pointer;
  margin-top: 30px;
}






@media (max-width: 1000px){
  nav{
    padding: 0 40px 0 50px;
  }
}
@media (max-width: 920px) {
  nav .menu-btn i{
    display: block;
  }
  #click:checked ~ .menu-btn i:before{
    content: "\f00d";
  }
  nav ul{
    position: fixed;
    top: 80px;
    left: -100%;
    background: #111;
    height: 100vh;
    width: 100%;
    text-align: center;
    display: block;
    transition: all 0.3s ease;
  }
  #click:checked ~ ul{
    left: 0;
  }
  nav ul li{
    width: 100%;
    margin: 40px 0;
  }
  nav ul li a{
    width: 100%;
    margin-left: -100%;
    display: block;
    font-size: 20px;
    transition: 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
  }
  #click:checked ~ ul li a{
    margin-left: 0px;
  }
  nav ul li a.active,
  nav ul li a:hover{
    background: none;
    color: cyan;
  }
}

    </style>
</head>
<body>


</body>

        <?php
           session_start();
           include('../connection_file/connection.php');
           $pass = $_SESSION['password'];
          

           if (!empty($pass)) {
           	// code...
           
               	$query = "SELECT * FROM new_std WHERE pass = '$pass'";
                $query_run = mysqli_query($con, $query);

                if (mysqli_num_rows($query_run) > 0) {
                              # code...
                              while ($row = mysqli_fetch_array($query_run)) {
                                 # code
                             ?>

                            <nav>
                                <div class="logo">
                                    Rajgad Hostel
                                </div>
                                <input type="checkbox" id="click">
                                <label for="click" class="menu-btn">
                                    <i class="fas fa-bars">X</i>
                                </label>
                                <ul>
                                    <li><a class="active" href="std_home.php">Home</a></li>
                                    <img src="" >
              
                                </ul>
                            </nav>


                            <center>
                            <div class="container">
                                <div class="left-section">
                                      <?php

                                        $query = "SELECT * FROM new_std WHERE pass = '$pass'";
                                        $result = mysqli_query($con, $query);
 
                                        while ($data = mysqli_fetch_array($result)) {
                                       
                                      ?>
                                        <img src="../image/<?php echo $data['image']; ?>">
 
                                    <?php
                                  }
                                    ?>
                                </div>

                                <div class="right-section">
                                  <form method="POST">

                                    <input type="text" name="name" value="<?php echo $row[0]?>">
                                    <input type="text" name="email" value="<?php echo $row[1]?>">
                                    <input type="text" name="address" value="<?php echo $row[2]?>">
                                    <input type="password" name="pass" value="<?php echo $row[3]?>">
                                    <input type="text" name="mobile_no" value="<?php echo $row[6]?>">
                                    <input type="text" name="college" value="<?php echo $row[11]?>">

                                    
                                    <center><button name="update">Update</button></center>

                                    <?php
                                      if (isset($_POST['update'])) {
                                        // code...
                                        
                                        $name = $_POST['name'];
                                        $email = $_POST['email'];
                                        $address = $_POST['address'];
                                        $pass = $_POST['pass'];
                                        $mobile_no = $_POST['mobile_no'];
                                        $college = $_POST['college'];

                                        


                                        $update_query = "update new_std set name = '$name', email = '$email', address = '$address', pass = '$pass', mobile_no = '$mobile_no', college = '$college' where pass = '$pass'";
                                        mysqli_query($con, $update_query);

                                        echo "Successfully Updated";
                                        

                                      }
                                    ?>

                                 </form>
                                </div>


                                </div>
                            </center>
                             <?php
                        }
                    }
            }
                
       
               
            ?>


</body>
</html>