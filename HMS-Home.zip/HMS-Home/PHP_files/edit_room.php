
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Update Room | Admin</title>
      <link rel="stylesheet" href="../css_files/edit_room.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
      <nav>
         <div class="logo">
            Rajgad Hostel
         </div>
         <input type="checkbox" id="click">
         <label for="click" class="menu-btn">
         <i class="fas fa-bars"></i>
         </label>
         <ul>
            <li><a class="active" href="ad_home.php">Home</a></li>
            <li><a href="new_std_manual.php">New Admission  </a></li>
            <li><a href="up_std.php">Update Student</a></li>
            <li><a href="fees.php">Fees</a></li>
            <li><a href="living_std.php">Living Student</a></li>
            <li><a href="leaved_std.php">Leaved Student</a></li>
         </ul>
      </nav>

      <center>
         <div class="container">
            <div class="input-section">
               <form method="POST">

                   <?php

                     include('../connection_file/connection.php');
                     
                     $rm = $_GET['rn'];
                     $rS = $_GET['rS'];
                     $status = $_GET['status'];
                     
                     ?>

                  <input type="text" name="room_no" value="<?php echo "$rm"?>" maxlength="4" placeholder="." required>
                  <input type="text" name="roomStatus" value="<?php echo "$rS"?>" placeholder="Status Of Room.." required>
                  <input type="text" name="status" value="<?php echo "$status"?>" placeholder="Status" required>

                  <center><button name="submit">Submit</button></center>
                  

                  <?php

                     include('../connection_file/connection.php');

                     if (isset($_POST['submit'])) {

                        $room_no = $_POST['room_no'];
                        $roomStatus = $_POST['roomStatus'];
                        $status = $_POST['status'];

                        if (!empty($room_no)) {
                           // code...
                           $query = "UPDATE rooms SET room_no = $room_no, roomStatus = '$roomStatus', status = '$status' where room_no = $room_no";
                           mysqli_query($con, $query);
                           
                           header("Location:ad_home.php");
                  
                        }
                     }


                  ?>


                  
               </form>
            </div>
         
         </div>
      </center>


   </body>


</html>